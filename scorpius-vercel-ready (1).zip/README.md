# SCORPIUS

موقع استوديو المنتجات الرقمية — تصميم وبرمجة وهوية بصرية بملكية كاملة.

## الرابط المطلوب
`https://scorpius.vercel.app`

## طريقة الرفع على Vercel (مجاني)

### الطريقة الأسهل (من المتصفح):

1. ادخل على [vercel.com](https://vercel.com) وسجّل بحساب GitHub (أو Google).
2. اضغط **Add New… → Project**.
3. لو المشروع مش على GitHub:
   - ارفعي المجلد ده على GitHub أولاً (Repository جديد اسمه مثلاً `scorpius`).
4. اختاري الـ Repository → **Import**.
5. في إعدادات المشروع:
   - **Project Name**: `scorpius`  ← ده هيخلي الرابط `scorpius.vercel.app`
   - Framework Preset: Vite (أو اتركه Auto)
   - Build Command: `npm run build`
   - Output Directory: اتركه فاضي (Nitro هيتعامل)
6. اضغط **Deploy**.

بعد دقيقتين الموقع هيبقى جاهز على:
**https://scorpius.vercel.app**

### لو عايزة دومين خاص بعدين:
من لوحة Vercel → Project → Settings → Domains → تضيفي أي دومين تشتريه (من Namecheap أو Cloudflare مثلاً).

## بعد النشر — عشان يطلع في جوجل بسرعة

1. ادخل [Google Search Console](https://search.google.com/search-console)
2. أضيفي الموقع `https://scorpius.vercel.app`
3. اعملي Submit للـ Sitemap (أو اتركي جوجل يزور الصفحة الرئيسية)
4. شاركي الرابط على كل حساباتك (واتساب، إنستجرام، فيسبوك، لينكدإن…)

## تشغيل محلي (للتجربة)

```bash
npm install
npm run dev
```

يفتح على `http://localhost:8080`

## ملاحظات
- الموقع جاهز للـ SSR على Vercel (Nitro preset).
- الـ Auth معطّل حالياً (VITE_AUTH_ENABLED=false).
- الصور والـ OG جاهزين في مجلد `public/`.
