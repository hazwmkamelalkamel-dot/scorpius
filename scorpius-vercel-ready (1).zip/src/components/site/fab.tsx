import { waLink } from "@/lib/site";
import { WhatsAppIcon } from "./whatsapp-icon";

export function WhatsAppFab() {
  return (
    <a
      href={waLink("مرحباً SCORPIUS، أريد أبدأ مشروع.")}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed start-4 bottom-24 z-40 grid size-12 place-items-center rounded-full bg-accent text-accent-fg shadow-[0_12px_40px_rgba(125,255,155,0.28)] transition-[transform,box-shadow] duration-150 hover:scale-105 active:scale-[0.96] md:start-6"
      aria-label="تواصل على واتساب"
    >
      <WhatsAppIcon className="size-6" />
    </a>
  );
}
