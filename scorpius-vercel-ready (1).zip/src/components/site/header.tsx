"use client";

import * as Dialog from "@radix-ui/react-dialog";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { NAV, waLink } from "@/lib/site";
import { cn } from "@/lib/utils";
import { WhatsAppIcon } from "./whatsapp-icon";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 8);
      const doc = document.documentElement;
      const max = doc.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? Math.min(1, y / max) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 border-b transition-[background-color,border-color] duration-200",
        scrolled
          ? "border-line bg-bg/86 backdrop-blur-xl"
          : "border-transparent bg-bg/40 backdrop-blur-md",
      )}
    >
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-accent/70"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 h-0.5 origin-right bg-accent"
        style={{ transform: `scaleX(${progress})` }}
        aria-hidden
      />
      <nav className="wrap flex h-[74px] items-center justify-between gap-4">
        <a
          href="#top"
          className="flex items-center gap-2.5 font-display text-[0.95rem] font-black tracking-widest"
        >
          <img
            src="/logo.jpg"
            alt="SCORPIUS"
            width={38}
            height={31}
            className="size-10 rounded-md object-cover"
          />
          <span>
            SCORPIUS <span className="text-accent">./</span>
          </span>
        </a>

        <div className="hidden items-center gap-7 text-[0.92rem] text-muted lg:flex">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="transition-colors duration-150 hover:text-accent"
            >
              {item.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <Button asChild variant="nav" size="sm" className="hidden sm:inline-flex">
            <a href={waLink()} target="_blank" rel="noopener noreferrer">
              ابدأ مشروعك
              <span aria-hidden>↗</span>
            </a>
          </Button>

          <Dialog.Root open={open} onOpenChange={setOpen}>
            <Dialog.Trigger asChild>
              <button
                type="button"
                className="grid size-11 place-items-center rounded-md border border-line text-fg lg:hidden"
                aria-label="فتح القائمة"
              >
                <Menu className="size-5" />
              </button>
            </Dialog.Trigger>
            <Dialog.Portal>
              <Dialog.Overlay className="fixed inset-0 z-50 bg-bg/80 backdrop-blur-sm" />
              <Dialog.Content
                className="menu-sheet fixed inset-y-0 start-0 z-50 flex flex-col border-e border-line bg-surface p-6 shadow-panel focus:outline-none"
                aria-describedby={undefined}
              >
                <div className="mb-8 flex items-center justify-between">
                  <Dialog.Title className="font-display text-sm font-black tracking-widest">
                    القائمة
                  </Dialog.Title>
                  <Dialog.Close asChild>
                    <button
                      type="button"
                      className="grid size-11 place-items-center rounded-md border border-line"
                      aria-label="إغلاق القائمة"
                    >
                      <X className="size-5" />
                    </button>
                  </Dialog.Close>
                </div>
                <nav className="flex flex-col gap-1">
                  {NAV.map((item) => (
                    <Dialog.Close asChild key={item.href}>
                      <a
                        href={item.href}
                        className="flex min-h-12 items-center rounded-md px-3 font-display text-lg font-bold hover:bg-raised hover:text-accent"
                      >
                        {item.label}
                      </a>
                    </Dialog.Close>
                  ))}
                </nav>
                <div className="mt-auto pt-6">
                  <Button asChild className="w-full" size="lg">
                    <a href={waLink()} target="_blank" rel="noopener noreferrer">
                      <WhatsAppIcon className="size-4" />
                      تواصل واتساب
                    </a>
                  </Button>
                </div>
              </Dialog.Content>
            </Dialog.Portal>
          </Dialog.Root>
        </div>
      </nav>
    </header>
  );
}
