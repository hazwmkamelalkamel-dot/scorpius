import { ArrowDown, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  FAQ,
  FOUNDER_STACK,
  IDENTITY,
  PACKAGES,
  PIPELINE,
  REASONS,
  STACK,
  STEPS,
  WA_DISPLAY,
  waLink,
} from "@/lib/site";
import { QuoteForm } from "./quote-form";
import { Reveal } from "./reveal";
import { WhatsAppIcon } from "./whatsapp-icon";

function SectionKicker({ children }: { children: string }) {
  return (
    <div className="mb-2 font-mono text-[0.73rem] font-bold tracking-[0.09em] text-accent">
      {children}
    </div>
  );
}

export function Landing() {
  return (
    <main id="top" className="relative z-10">
      <Hero />
      <Services />
      <Identity />
      <Process />
      <Why />
      <Founder />
      <Faq />
      <Contact />
      <Footer />
    </main>
  );
}

function Hero() {
  return (
    <section className="relative py-14 md:py-20 lg:hero-min lg:py-0">
      <div className="wrap grid items-center gap-12 lg:hero-min lg:grid-cols-[1.08fr_0.92fr] lg:gap-14">
        <Reveal>
          <div className="mb-5 inline-flex items-center gap-2.5 rounded-full border border-line-strong px-3 py-1.5 font-mono text-[0.72rem] font-bold tracking-[0.04em] text-accent">
            <i className="pulse-dot size-1.5 rounded-full bg-accent" />
            DIGITAL PRODUCT STUDIO · 2026
          </div>
          <h1 className="max-w-[18ch] font-display text-hero font-black leading-[1.05] tracking-display">
            نبني فكرتك كـ <span className="text-accent">منتج حقيقي.</span>
          </h1>
          <p className="mt-6 max-w-[38rem] text-[1.08rem] leading-relaxed text-muted">
            تصميم، برمجة، وهوية بصرية — من أول فكرة لحد التسليم. تدفع مقابل
            المشروع مرة واحدة، والمنتج والكود والتصاميم ملكك بالكامل.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <a href={waLink()} target="_blank" rel="noopener noreferrer">
                <WhatsAppIcon className="size-4" />
                تواصل واتساب
              </a>
            </Button>
            <Button asChild variant="ghost" size="lg">
              <a href="#services">
                استكشف الخدمات
                <ArrowDown className="size-4" />
              </a>
            </Button>
          </div>
          <div className="mt-10 grid overflow-hidden rounded-lg border border-line sm:grid-cols-3">
            <Stat value="100%" label="ملكية الكود والتصميم" />
            <Stat value="50 / 50" label="نظام دفع واضح" />
            <Stat value="30 يوم" label="ضمان أخطاء تقنية" last />
          </div>
        </Reveal>

        <Reveal delayMs={80}>
          <div className="relative overflow-hidden rounded-xl border border-line-strong bg-linear-to-br from-raised to-bg shadow-panel">
            <div className="flex items-center gap-2 border-b border-line px-4 py-3.5 font-mono text-[0.68rem] font-bold text-subtle">
              <i className="pulse-dot size-2 rounded-full bg-accent" />
              <i className="size-2 rounded-full bg-line-strong" />
              <i className="size-2 rounded-full bg-line-strong" />
              <span className="ms-auto">scorpius@studio:~</span>
              <span className="text-accent">SECURE_BUILD</span>
            </div>
            <div className="relative px-6 py-8 md:px-8 md:py-10">
              <div className="font-mono text-[0.68rem] font-bold tracking-[0.08em] text-subtle">
                SYSTEM / PRODUCT ENGINEERING / ONLINE
              </div>
              <div className="mx-auto my-7 grid size-[148px] place-items-center rounded-[22px] border border-line-strong bg-bg p-2.5">
                <img
                  src="/logo.jpg"
                  alt="شعار SCORPIUS"
                  width={240}
                  height={193}
                  className="h-full w-full rounded-[14px] object-cover"
                />
              </div>
              <h2 className="font-display text-panel font-black leading-none">
                BUILD
                <br />
                <em className="not-italic text-accent">WITHOUT LIMITS.</em>
              </h2>
              <div className="mt-6 space-y-1 border-t border-line pt-4 font-mono text-[0.76rem] leading-8 text-muted">
                {PIPELINE.map((row) => (
                  <div key={row.n} className="pipeline-row flex justify-between gap-3">
                    <span>
                      <b className="text-accent">{row.n}</b>
                      <span className="ms-2">{row.label}</span>
                    </span>
                    <span className="text-accent">{row.status}</span>
                  </div>
                ))}
              </div>
              <div className="mt-6 inline-flex rounded-md border border-line-strong bg-bg px-3 py-2 font-mono text-[0.66rem] font-bold tracking-wide text-accent">
                NO MONTHLY SUBSCRIPTIONS
              </div>
              <span
                aria-hidden
                className="pointer-events-none absolute start-5 bottom-3 font-mono text-6xl font-bold text-line"
              >
                +
              </span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Stat({
  value,
  label,
  last = false,
}: {
  value: string;
  label: string;
  last?: boolean;
}) {
  return (
    <div
      className={`bg-fg/[0.015] px-5 py-5 ${last ? "" : "border-b border-line sm:border-b-0 sm:border-s"}`}
    >
      <b className="mb-1 block font-mono text-xl font-extrabold text-accent">{value}</b>
      <span className="text-sm text-muted">{label}</span>
    </div>
  );
}

function Services() {
  return (
    <section id="services" className="py-20 md:py-28">
      <div className="wrap">
        <Reveal>
          <SectionKicker>01 — SERVICES</SectionKicker>
          <h2 className="max-w-[16ch] text-section font-black">
            الخدمة مش مجرد تنفيذ.
            <br />
            دي رحلة بناء كاملة.
          </h2>
          <p className="mt-3 max-w-[38rem] text-muted">
            من الفكرة الأولية إلى منتج جاهز للسوق، بنجمع الاستراتيجية والتصميم
            والهندسة في مسار واحد واضح.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-4 lg:grid-cols-2">
          {PACKAGES.map((pkg, i) => (
            <Reveal key={pkg.id} delayMs={i * 60}>
              <article
                className={`relative flex h-full flex-col overflow-hidden rounded-xl border bg-linear-to-br from-raised to-surface p-7 ${pkg.featured ? "border-line-strong" : "border-line"}`}
              >
                {pkg.featured ? (
                  <span className="absolute end-5 top-5 rounded-md bg-accent px-2 py-1 font-mono text-[0.64rem] font-extrabold text-accent-fg">
                    الأكثر طلباً
                  </span>
                ) : null}
                <div className="mb-3 font-mono text-[0.72rem] font-bold text-accent">
                  {pkg.code}
                </div>
                <h3 className="font-display text-[1.35rem] font-black">
                  {pkg.title}
                  <span className="mt-1 block text-sm font-bold text-muted">
                    {pkg.en}
                  </span>
                </h3>
                <p className="mt-2 mb-5 text-[0.92rem] text-muted">{pkg.desc}</p>
                <ul className="border-t border-line">
                  {pkg.features.map((f) => (
                    <li
                      key={f}
                      className="flex items-start gap-2.5 border-b border-line py-2.5 text-[0.9rem]"
                    >
                      <Check className="mt-0.5 size-4 shrink-0 text-accent" />
                      {f}
                    </li>
                  ))}
                </ul>
                <div className="mt-4 font-mono text-[0.67rem] font-bold text-muted">
                  DELIVERY <span className="text-fg">{pkg.delivery}</span>
                </div>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-md border border-dashed border-line-strong bg-bg px-4 py-3">
                  <small className="text-xs text-muted">{pkg.note}</small>
                  <strong className="font-mono text-[0.95rem] font-extrabold text-accent">
                    {pkg.price}
                  </strong>
                </div>
                <Button asChild className="mt-5 w-full" variant={pkg.featured ? "primary" : "ghost"}>
                  <a href={waLink(pkg.wa)} target="_blank" rel="noopener noreferrer">
                    اطلب هذه الباقة
                  </a>
                </Button>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Identity() {
  return (
    <section id="identity" className="py-20 md:py-28">
      <div className="wrap">
        <Reveal>
          <SectionKicker>02 — VISUAL IDENTITY</SectionKicker>
          <h2 className="max-w-[16ch] text-section font-black">
            التصميم اللي يخلي
            <br />
            المنتج يتشاف.
          </h2>
          <p className="mt-3 max-w-[38rem] text-muted">
            هوية بصرية متماسكة من اللوجو لحد محتوى السوشيال، ومخرجات عملية تقدر
            تستخدمها فعلاً.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {IDENTITY.map((item, i) => (
            <Reveal key={item.code} delayMs={i * 50}>
              <article className="h-full rounded-lg border border-line bg-fg/[0.015] p-6">
                <div className="mb-5 grid size-11 place-items-center rounded-md border border-line-strong font-mono text-sm font-extrabold text-accent">
                  {item.code}
                </div>
                <h3 className="font-display text-[1.05rem] font-black">{item.title}</h3>
                <p className="mt-1.5 mb-4 text-[0.88rem] text-muted">{item.desc}</p>
                <strong className="font-mono text-[0.86rem] font-extrabold text-accent">
                  {item.price}
                </strong>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Process() {
  return (
    <section id="process" className="py-20 md:py-28">
      <div className="wrap">
        <Reveal>
          <SectionKicker>03 — WORKFLOW</SectionKicker>
          <h2 className="max-w-[16ch] text-section font-black">
            من أول مكالمة
            <br />
            لحد المنتج في إيدك.
          </h2>
          <p className="mt-3 max-w-[38rem] text-muted">
            مفيش قفزات مجهولة. كل مرحلة ليها مخرج واضح وتوقيت مفهوم.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-3 md:grid-cols-5">
          {STEPS.map((step, i) => (
            <Reveal key={step.code} delayMs={i * 40} className="h-full">
              <article className="flex h-full flex-col rounded-lg border border-line bg-linear-to-b from-raised to-bg p-5">
                <div className="mb-5 font-mono text-[0.7rem] font-extrabold text-accent">
                  {step.code}
                </div>
                <h3 className="font-display text-base font-black">{step.title}</h3>
                <p className="mt-2 flex-1 text-[0.82rem] leading-relaxed text-muted">
                  {step.body}
                </p>
                <span className="mt-4 font-mono text-[0.62rem] font-bold text-subtle">
                  {step.when}
                </span>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function Why() {
  return (
    <section id="why" className="py-20 md:py-28">
      <div className="wrap">
        <Reveal>
          <SectionKicker>04 — WHY SCORPIUS</SectionKicker>
          <h2 className="max-w-[16ch] text-section font-black">
            وضوح في الاتفاق.
            <br />
            ملكية في النهاية.
          </h2>
          <p className="mt-3 max-w-[38rem] text-muted">
            القيمة هنا مش في عدد البنود؛ في إنك تعرف هتدفع إيه، هتستلم إيه، ومين
            يملك إيه.
          </p>
        </Reveal>
        <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          {REASONS.map((item, i) => (
            <Reveal key={item.code} delayMs={i * 40} className={i < 2 ? "lg:col-span-3" : "lg:col-span-2"}>
              <article className="flex h-full gap-4 rounded-lg border border-line p-6">
                <div className="grid size-11 shrink-0 place-items-center rounded-full border border-line-strong font-mono text-[0.72rem] font-bold text-accent">
                  {item.code}
                </div>
                <div>
                  <h3 className="font-display text-base font-black">{item.title}</h3>
                  <p className="mt-1 text-[0.86rem] text-muted">{item.body}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
        <Reveal>
          <div className="mt-6 flex flex-wrap gap-2">
            {STACK.map((tech) => (
              <span
                key={tech}
                className="rounded-full border border-line px-3 py-1.5 font-mono text-[0.67rem] font-bold text-muted"
              >
                {tech}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Founder() {
  return (
    <section id="founder" className="py-20 md:py-28">
      <div className="wrap max-w-3xl">
        <Reveal>
          <div className="font-mono text-[0.7rem] font-bold tracking-[0.06em] text-accent">
            FOUNDER · FULL-STACK DEVELOPER
          </div>
          <h2 className="mt-2 text-section font-black">
            من خلف SCORPIUS
          </h2>
          <div className="mt-2 font-mono text-xl font-extrabold text-accent">
            Hazem Mohammed Kamel
          </div>
          <p className="mt-4 max-w-[42rem] text-muted">
            المؤسس والمطوّر الرئيسي لاستوديو SCORPIUS، مسؤول عن بناء كل مشروع من
            الفكرة إلى التسليم النهائي — برمجةً وتصميماً.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            {FOUNDER_STACK.map((tag) => (
              <span
                key={tag}
                className="rounded-full border border-line px-3 py-1.5 font-mono text-[0.67rem] font-bold text-muted"
              >
                {tag}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Faq() {
  return (
    <section id="faq" className="py-20 md:py-28">
      <div className="wrap">
        <Reveal>
          <SectionKicker>05 — FAQ</SectionKicker>
          <h2 className="text-section font-black">
            أسئلة بيسألها كل عميل.
          </h2>
          <p className="mt-3 max-w-[38rem] text-muted">
            ولو سؤالك مش موجود هنا، التواصل المباشر أسرع.
          </p>
        </Reveal>
        <Reveal>
          <Accordion type="single" collapsible className="mt-10 border-t border-line">
            {FAQ.map((item, i) => (
              <AccordionItem key={item.q} value={`q-${i}`}>
                <AccordionTrigger>{item.q}</AccordionTrigger>
                <AccordionContent>
                  <p>{item.a}</p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="start" className="pb-20 md:pb-28">
      <div className="wrap">
        <Reveal>
          <div className="relative overflow-hidden rounded-xl border border-line-strong contact-panel px-5 py-12 md:px-10 md:py-16">
            <span
              aria-hidden
              className="pointer-events-none absolute start-4 -bottom-8 font-mono text-[9rem] font-black leading-none text-line/80"
            >
              01
            </span>
            <div className="relative grid items-start gap-10 lg:grid-cols-[1fr_minmax(0,24rem)]">
              <div className="text-center lg:pt-4 lg:text-start">
                <SectionKicker>06 — START A PROJECT</SectionKicker>
                <h2 className="text-section font-black">
                  جاهز نطلع الفكرة
                  <br />
                  من دماغك للسوق؟
                </h2>
                <p className="mx-auto mt-3 max-w-[36rem] text-muted lg:mx-0">
                  اكتب تفاصيل سريعة، أو تواصل مباشرة على واتساب — نرجع لك بعرض
                  سعر ومدة تسليم واضحين.
                </p>
                <Button asChild size="lg" className="mt-6">
                  <a href={waLink()} target="_blank" rel="noopener noreferrer">
                    <WhatsAppIcon className="size-4" />
                    تواصل على واتساب
                  </a>
                </Button>
                <div className="mt-4 font-mono text-[0.78rem] text-muted">
                  <a
                    href={`tel:+${"201050094382"}`}
                    className="font-extrabold text-accent"
                    dir="ltr"
                  >
                    {WA_DISPLAY}
                  </a>
                  {" · "}
                  SCORPIUS DIGITAL PRODUCT STUDIO
                </div>
              </div>
              <QuoteForm />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-line py-7 text-[0.78rem] text-subtle">
      <div className="wrap flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <span>© 2026 SCORPIUS — جميع الحقوق محفوظة</span>
        <b className="font-mono text-[0.7rem] tracking-wide text-muted">
          CRAFTED IN-HOUSE · DELIVERED WITH PRECISION.
        </b>
      </div>
    </footer>
  );
}
