"use client";

import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { PROJECT_TYPES, waLink } from "@/lib/site";
import { WhatsAppIcon } from "./whatsapp-icon";

const fieldClass =
  "h-11 w-full rounded-md border border-line bg-bg px-3.5 text-fg outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-subtle focus:border-line-strong focus:shadow-[0_0_0_3px_rgba(125,255,155,0.12)]";

export function QuoteForm() {
  const [name, setName] = useState("");
  const [type, setType] = useState<string>(PROJECT_TYPES[0]);
  const [details, setDetails] = useState("");
  const [error, setError] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError("اكتب اسمك عشان نقدر نرد عليك.");
      return;
    }
    setError("");
    const message = [
      `مرحباً SCORPIUS، أنا ${trimmed}.`,
      `نوع المشروع: ${type}`,
      details.trim() ? `التفاصيل:\n${details.trim()}` : "أريد عرض سعر للمشروع.",
    ].join("\n\n");
    window.open(waLink(message), "_blank", "noopener,noreferrer");
  }

  return (
    <form
      onSubmit={onSubmit}
      className="flex flex-col gap-4 rounded-xl border border-line bg-surface p-5 md:p-6"
    >
      <div className="flex flex-col gap-1.5">
        <label htmlFor="quote-name" className="text-sm font-bold text-fg">
          الاسم
        </label>
        <input
          id="quote-name"
          name="name"
          autoComplete="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="اسمك"
          className={fieldClass}
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <label htmlFor="quote-type" className="text-sm font-bold text-fg">
          نوع المشروع
        </label>
        <select
          id="quote-type"
          name="type"
          value={type}
          onChange={(e) => setType(e.target.value)}
          className={fieldClass}
        >
          {PROJECT_TYPES.map((opt) => (
            <option key={opt} value={opt}>
              {opt}
            </option>
          ))}
        </select>
      </div>
      <div className="flex flex-col gap-1.5">
        <label htmlFor="quote-details" className="text-sm font-bold text-fg">
          تفاصيل الفكرة
        </label>
        <textarea
          id="quote-details"
          name="details"
          rows={4}
          value={details}
          onChange={(e) => setDetails(e.target.value)}
          placeholder="اشرح الفكرة في سطرين… الميزات، الجمهور، والموعد المطلوب إن وجد."
          className="min-h-28 w-full resize-y rounded-lg border border-line bg-bg px-3.5 py-3 text-fg outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-subtle focus:border-line-strong focus:shadow-[0_0_0_3px_rgba(125,255,155,0.12)]"
        />
      </div>
      {error ? <p className="text-sm text-danger">{error}</p> : null}
      <Button type="submit" size="lg" className="w-full">
        <WhatsAppIcon className="size-4" />
        أرسل على واتساب
      </Button>
      <p className="text-center text-xs text-subtle">
        هيفتح واتساب برسالة جاهزة — من غير تسجيل أو انتظار.
      </p>
    </form>
  );
}
