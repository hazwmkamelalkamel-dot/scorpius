import { createFileRoute } from "@tanstack/react-router";
import { WhatsAppFab } from "@/components/site/fab";
import { Header } from "@/components/site/header";
import { Landing } from "@/components/site/landing";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <>
      <Header />
      <Landing />
      <WhatsAppFab />
    </>
  );
}
